# RietiLife — pubblicazione su Render

Questo pacchetto è predisposto per Render con nome servizio `rietilife` e disco persistente per il database SQLite.

## Pubblicazione
1. Estrai questa cartella.
2. Carica il contenuto in un nuovo repository GitHub (non includere password o chiavi personali).
3. Su Render scegli **New + → Blueprint** e collega il repository.
4. Render leggerà `render.yaml` e creerà il servizio `rietilife`.
5. Quando richiesto, inserisci `ADMIN_PASSWORD` nel pannello Render usando una password lunga e unica.
6. Avvia il deploy. Se il nome è disponibile, l'indirizzo sarà `https://rietilife.onrender.com`.

## Nota sui costi
La configurazione usa un'istanza Starter e un disco persistente: possono essere a pagamento secondo il listino Render. Il disco evita che il database SQLite venga perso a ogni riavvio/deploy.

## Sicurezza
Non pubblicare mai file con password o chiavi. `SECRET_KEY` viene generata da Render; `ADMIN_PASSWORD` va inserita come variabile segreta nel pannello. Cambia la password iniziale usata in precedenza: non riutilizzarla.
