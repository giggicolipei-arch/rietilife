import os
import sqlite3
import tempfile
import unittest

TMP = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(TMP, "test.db")
os.environ["ADMIN_PASSWORD"] = "pw-di-prova"
os.environ["SECRET_KEY"] = "chiave-di-prova"

import app as tracker  # noqa: E402

DESKTOP = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
           "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
IPHONE = ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 "
          "(KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1")
BOT = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"


def db():
    con = sqlite3.connect(os.environ["DB_PATH"])
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def post(client, path, **data):
    with client.session_transaction() as s:
        token = s.setdefault("_csrf", "token-di-prova")
    return client.post(path, data={**data, "_csrf": token})


class TrackerTests(unittest.TestCase):
    def setUp(self):
        tracker.FAILS.clear()
        con = db()
        con.execute("DELETE FROM clicks")
        con.execute("DELETE FROM links")
        con.commit()
        con.close()
        self.admin = tracker.app.test_client()
        post(self.admin, "/admin/login", password="pw-di-prova")

    def create(self, **kw):
        data = {"url": "https://esempio.com/pagina", "code": "promo"}
        data.update(kw)
        return post(self.admin, "/admin/links", **data)

    def clicks(self):
        con = db()
        n = con.execute("SELECT COUNT(*) FROM clicks").fetchone()[0]
        con.close()
        return n

    # --- accesso ---------------------------------------------------------
    def test_admin_requires_login(self):
        r = tracker.app.test_client().get("/admin")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/admin/login", r.headers["Location"])

    def test_wrong_password(self):
        c = tracker.app.test_client()
        r = post(c, "/admin/login", password="sbagliata")
        self.assertIn(b"Password errata", r.data)
        self.assertEqual(c.get("/admin").status_code, 302)

    def test_login_lockout(self):
        c = tracker.app.test_client()
        for _ in range(5):
            post(c, "/admin/login", password="x")
        r = post(c, "/admin/login", password="pw-di-prova")
        self.assertEqual(r.status_code, 429)

    def test_csrf_required(self):
        r = self.admin.post("/admin/links", data={"url": "https://a.com"})
        self.assertEqual(r.status_code, 400)

    # --- creazione -------------------------------------------------------
    def test_create_and_redirect_with_utm(self):
        self.create(utm_source="newsletter", utm_medium="email")
        r = tracker.app.test_client().get(
            "/promo", headers={"User-Agent": DESKTOP})
        self.assertEqual(r.status_code, 302)
        loc = r.headers["Location"]
        self.assertTrue(loc.startswith("https://esempio.com/pagina?"))
        self.assertIn("utm_source=newsletter", loc)
        self.assertIn("utm_medium=email", loc)
        self.assertEqual(self.clicks(), 1)

    def test_existing_utm_not_overridden(self):
        self.create(url="https://esempio.com/?utm_source=mio", utm_source="altro")
        r = tracker.app.test_client().get("/promo", headers={"User-Agent": DESKTOP})
        self.assertIn("utm_source=mio", r.headers["Location"])
        self.assertNotIn("altro", r.headers["Location"])

    def test_url_without_scheme_gets_https(self):
        self.create(url="esempio.com")
        r = tracker.app.test_client().get("/promo", headers={"User-Agent": DESKTOP})
        self.assertTrue(r.headers["Location"].startswith("https://esempio.com"))

    def test_dangerous_urls_rejected(self):
        for bad in ("javascript:alert(1)", "ftp://esempio.com/file", "data:text/html,x", "http://"):
            self.create(url=bad, code="x" + str(abs(hash(bad)) % 1000))
        con = db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM links").fetchone()[0], 0)
        con.close()

    def test_no_self_redirect(self):
        self.create(url="http://localhost/qualcosa")
        self.assertEqual(tracker.app.test_client().get("/promo").status_code, 404)

    def test_duplicate_and_reserved_codes(self):
        self.create()
        self.create(url="https://altro.com")
        con = db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM links").fetchone()[0], 1)
        con.close()
        self.create(code="admin")
        self.create(code="a b")
        con = db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM links").fetchone()[0], 1)
        con.close()

    def test_random_code_generated(self):
        self.create(code="")
        con = db()
        code = con.execute("SELECT code FROM links").fetchone()["code"]
        con.close()
        self.assertGreaterEqual(len(code), 6)
        r = tracker.app.test_client().get("/" + code, headers={"User-Agent": DESKTOP})
        self.assertEqual(r.status_code, 302)

    # --- conteggio -------------------------------------------------------
    def test_bots_and_head_not_counted(self):
        self.create()
        c = tracker.app.test_client()
        c.get("/promo", headers={"User-Agent": BOT})
        c.get("/promo", headers={"User-Agent": ""})
        c.head("/promo", headers={"User-Agent": DESKTOP})
        c.get("/promo", headers={"User-Agent": DESKTOP, "Sec-Purpose": "prefetch"})
        self.assertEqual(self.clicks(), 0)

    def test_device_browser_referrer(self):
        self.create()
        c = tracker.app.test_client()
        c.get("/promo", headers={"User-Agent": IPHONE, "Referer": "https://www.instagram.com/p/abc"})
        c.get("/promo", headers={"User-Agent": DESKTOP})
        con = db()
        rows = con.execute("SELECT referrer, device, browser FROM clicks ORDER BY id").fetchall()
        con.close()
        self.assertEqual(tuple(rows[0]), ("instagram.com", "Mobile", "Safari"))
        self.assertEqual(tuple(rows[1]), ("Diretto", "Desktop", "Chrome"))

    def test_unknown_link_404(self):
        self.assertEqual(tracker.app.test_client().get("/nonesiste").status_code, 404)
        self.assertEqual(tracker.app.test_client().get("/favicon.ico").status_code, 404)

    # --- gestione --------------------------------------------------------
    def test_toggle_returns_410(self):
        self.create()
        con = db()
        lid = con.execute("SELECT id FROM links").fetchone()["id"]
        con.close()
        post(self.admin, f"/admin/links/{lid}/toggle")
        c = tracker.app.test_client()
        self.assertEqual(c.get("/promo", headers={"User-Agent": DESKTOP}).status_code, 410)
        self.assertEqual(self.clicks(), 0)
        post(self.admin, f"/admin/links/{lid}/toggle")
        self.assertEqual(c.get("/promo", headers={"User-Agent": DESKTOP}).status_code, 302)

    def test_delete_cascades_clicks(self):
        self.create()
        tracker.app.test_client().get("/promo", headers={"User-Agent": DESKTOP})
        self.assertEqual(self.clicks(), 1)
        con = db()
        lid = con.execute("SELECT id FROM links").fetchone()["id"]
        con.close()
        post(self.admin, f"/admin/links/{lid}/delete")
        self.assertEqual(self.clicks(), 0)

    def test_pages_render_and_csv(self):
        self.create(utm_campaign="nov")
        c = tracker.app.test_client()
        c.get("/promo", headers={"User-Agent": IPHONE, "Referer": "https://t.co/x"})
        con = db()
        lid = con.execute("SELECT id FROM links").fetchone()["id"]
        con.close()
        dash = self.admin.get("/admin")
        self.assertEqual(dash.status_code, 200)
        self.assertIn(b"/promo", dash.data)
        detail = self.admin.get(f"/admin/links/{lid}")
        self.assertEqual(detail.status_code, 200)
        self.assertIn(b"t.co", detail.data)
        self.assertIn(b"utm_campaign=nov", detail.data)
        export = self.admin.get(f"/admin/links/{lid}/export.csv")
        self.assertEqual(export.mimetype, "text/csv")
        self.assertIn(b"data_ora,provenienza,dispositivo,browser", export.data)
        self.assertIn(b"t.co,Mobile,Safari", export.data)
        self.assertEqual(self.admin.get("/admin/links/99999").status_code, 404)


if __name__ == "__main__":
    unittest.main()
